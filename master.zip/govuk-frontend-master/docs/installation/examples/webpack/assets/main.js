import Button from 'govuk-frontend/govuk/components/button/button'

new Button(document).init()
