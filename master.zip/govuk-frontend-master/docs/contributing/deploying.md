## Deploying
You can [run the preview app locally](running-locally.md) or deploy it straight to a Heroku instance.

An existing Heroku instance can be found at: [http://govuk-frontend-review.herokuapp.com/](http://govuk-frontend-review.herokuapp.com/)
