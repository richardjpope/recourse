/**
 * @jest-environment jsdom
 */
/* eslint-env jest */

const { axe } = require('jest-axe')

const { render, getExamples, htmlWithClassName } = require('../../../../lib/jest-helpers')

const examples = getExamples('textarea')

const WORD_BOUNDARY = '\\b'

describe('Character count', () => {
  describe('by default', () => {
    it('passes accessibility tests', async () => {
      const $ = render('character-count', examples.default)

      const results = await axe($.html())
      expect(results).toHaveNoViolations()
    })

    it('renders with classes', () => {
      const $ = render('character-count', {
        classes: 'app-character-count--custom-modifier'
      })

      const $component = $('.govuk-js-character-count')
      expect($component.hasClass('app-character-count--custom-modifier')).toBeTruthy()
    })

    it('renders with id', () => {
      const $ = render('character-count', {
        id: 'my-character-count'
      })

      const $component = $('.govuk-js-character-count')
      expect($component.attr('id')).toEqual('my-character-count')
    })

    it('renders with name', () => {
      const $ = render('character-count', {
        name: 'my-character-count-name'
      })

      const $component = $('.govuk-js-character-count')
      expect($component.attr('name')).toEqual('my-character-count-name')
    })

    it('renders with rows', () => {
      const $ = render('character-count', {
        rows: '4'
      })

      const $component = $('.govuk-js-character-count')
      expect($component.attr('rows')).toEqual('4')
    })

    it('renders with default number of rows', () => {
      const $ = render('character-count', {})

      const $component = $('.govuk-js-character-count')
      expect($component.attr('rows')).toEqual('5')
    })

    it('renders with value', () => {
      const $ = render('character-count', {
        value: '221B Baker Street\nLondon\nNW1 6XE\n'
      })

      const $component = $('.govuk-js-character-count')
      expect($component.text()).toEqual('221B Baker Street\nLondon\nNW1 6XE\n')
    })

    it('renders with attributes', () => {
      const $ = render('character-count', {
        attributes: {
          'data-attribute': 'my data value'
        }
      })

      const $component = $('.govuk-js-character-count')
      expect($component.attr('data-attribute')).toEqual('my data value')
    })

    it('renders with formGroup', () => {
      const $ = render('character-count', {
        formGroup: {
          classes: 'app-character-count--custom-modifier'
        }
      })

      const $component = $('.govuk-form-group')
      expect($component.hasClass('app-character-count--custom-modifier')).toBeTruthy()
    })
  })

  describe('count message', () => {
    it('renders with the amount of characters expected', () => {
      const $ = render('character-count', {
        maxlength: 10
      })

      const $countMessage = $('.govuk-character-count__message')
      expect($countMessage.text()).toContain('You can enter up to 10 characters')
    })
    it('renders with the amount of words expected', () => {
      const $ = render('character-count', {
        maxwords: 10
      })

      const $countMessage = $('.govuk-character-count__message')
      expect($countMessage.text()).toContain('You can enter up to 10 words')
    })
    it('is associated with the textarea', () => {
      const $ = render('character-count', {
        maxlength: 10
      })

      const $textarea = $('.govuk-js-character-count')
      const $countMessage = $('.govuk-character-count__message')

      const hintId = new RegExp(
        WORD_BOUNDARY + $countMessage.attr('id') + WORD_BOUNDARY
      )

      expect($textarea.attr('aria-describedby'))
        .toMatch(hintId)
    })
    it('renders with custom classes', () => {
      const $ = render('character-count', {
        countMessage: {
          classes: 'app-custom-count-message'
        }
      })

      const $countMessage = $('.govuk-character-count__message')
      expect($countMessage.hasClass('app-custom-count-message')).toBeTruthy()
    })
    it('renders with aria live set to polite', () => {
      const $ = render('character-count', {})

      const $countMessage = $('.govuk-character-count__message')
      expect($countMessage.attr('aria-live')).toEqual('polite')
    })
  })

  describe('when it includes a hint', () => {
    it('renders with hint', () => {
      const $ = render('character-count', {
        id: 'character-count-with-hint',
        maxlength: 10,
        hint: {
          text: 'It’s on your National Insurance card, benefit letter, payslip or P60. For example, ‘QQ 12 34 56 C’.'
        }
      })

      expect(htmlWithClassName($, '.govuk-hint')).toMatchSnapshot()
    })

    it('associates the character count as "described by" the hint', () => {
      const $ = render('character-count', {
        id: 'character-count-with-hint',
        hint: {
          text: 'It’s on your National Insurance card, benefit letter, payslip or P60. For example, ‘QQ 12 34 56 C’.'
        }
      })

      const $textarea = $('.govuk-js-character-count')
      const $hint = $('.govuk-hint')

      const hintId = new RegExp(
        WORD_BOUNDARY + $hint.attr('id') + WORD_BOUNDARY
      )

      expect($textarea.attr('aria-describedby'))
        .toMatch(hintId)
    })
  })

  describe('when it includes an error message', () => {
    it('renders with error message', () => {
      const $ = render('character-count', {
        id: 'character-count-with-error',
        errorMessage: {
          text: 'Error message'
        }
      })

      expect(htmlWithClassName($, '.govuk-error-message')).toMatchSnapshot()
    })

    it('associates the character-count as "described by" the error message', () => {
      const $ = render('character-count', {
        id: 'character-count-with-error',
        errorMessage: {
          text: 'Error message'
        }
      })

      const $component = $('.govuk-js-character-count')
      const $errorMessage = $('.govuk-error-message')

      const errorMessageId = new RegExp(
        WORD_BOUNDARY + $errorMessage.attr('id') + WORD_BOUNDARY
      )

      expect($component.attr('aria-describedby'))
        .toMatch(errorMessageId)
    })

    it('adds the error class to the character-count', () => {
      const $ = render('character-count', {
        errorMessage: {
          text: 'Error message'
        }
      })

      const $component = $('.govuk-js-character-count')
      expect($component.hasClass('govuk-textarea--error')).toBeTruthy()
    })

    it('renders with classes', () => {
      const $ = render('character-count', {
        errorMessage: {
          text: 'Error message'
        },
        classes: 'app-character-count--custom-modifier'
      })

      const $component = $('.govuk-js-character-count')
      expect($component.hasClass('app-character-count--custom-modifier')).toBeTruthy()
    })
  })

  describe('with dependant components', () => {
    it('have correct nesting order', () => {
      const $ = render('character-count', {
        id: 'nested-order',
        label: {
          text: 'Full address'
        },
        errorMessage: {
          text: 'Error message'
        }
      })

      const $component = $('.govuk-form-group > .govuk-js-character-count')
      expect($component.length).toBeTruthy()
    })

    it('renders with label', () => {
      const $ = render('character-count', {
        id: 'my-character-count',
        label: {
          text: 'Full address'
        }
      })

      expect(htmlWithClassName($, '.govuk-label')).toMatchSnapshot()
    })

    it('renders label with "for" attribute reffering the character count "id"', () => {
      const $ = render('character-count', {
        id: 'my-character-count',
        label: {
          text: 'Full address'
        }
      })

      const $label = $('.govuk-label')
      expect($label.attr('for')).toEqual('my-character-count')
    })
  })
})
